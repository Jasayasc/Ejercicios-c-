#include "persona.h"

persona::persona() {
	setNombre("NN");
	setSexo('N');
	setEdad(0);
}
persona::persona(string n, char s, int e) {
	setNombre(n);
	setSexo(s);
	setEdad(e);
}
persona::~persona() {
	;
}
void persona::setNombre(string n) {
	nombre = n;
}
void persona::setSexo(char c) {
	sexo = c;
}
void persona::setEdad(int e) {
	edad = e;
}
string persona::getNombre() {
	return nombre;
}
char persona::getSexo() {
	return sexo;
}
int persona::getEdad() {
	return edad;
}
void persona::imprimir() {
	cout<<"\tNombre: "<<getNombre()<<"   Sexo: "<<getSexo()<<"   "<<"   Edad: "<<getEdad()<<endl;
}
