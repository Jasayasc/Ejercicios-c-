#ifndef ARBOL_H
#define ARBOL_H
#include "nodo_a.h"
using std::string;

class arbol
{
	private:
		nodo_a *raizPtr;
	public:
		arbol();
		~arbol();
		
		void setraizPtr(nodo_a *);
		nodo_a* getRaizPtr();
		void ayudaInsertar(persona , nodo_a* &);
		void insertar(persona );
		void inOrden();
		void preOrden();
		void posOrden();
		void mostrarInOrden(nodo_a *);
		void mostrarPreOrden(nodo_a *);
		void mostrarPosOrden(nodo_a *);
		void imprimir();
		void leer(string);
	protected:
};

#endif
