#ifndef PERSONA_H
#define PERSONA_H
#include <string>
using std::string;

#include <iostream>
using std::cout;
using std::endl;


class persona
{
	private:
		string nombre;
		char sexo;
		int edad;
	public:
		persona();
		persona(string, char, int);
		~persona();
		
		void setNombre(string);
		void setSexo(char);
		void setEdad(int);
		
		string getNombre();
		int getEdad();
		char getSexo();
		
		void imprimir();
};

#endif
