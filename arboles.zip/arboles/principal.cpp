#include "arbol.h"
#include "persona.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	arbol x;
	persona y;
	y.imprimir();
	x.leer("datosPersonales.txt");
	cout<<endl<<"Lectura inOrden: "<<endl;
	x.inOrden();
	cout<<"\n\nLectura PreOrden\n";
	x.preOrden();
	cout<<"\n\nLectura PosOrden\n";
	x.posOrden();
	//x.imprimir();
	/*
		
	*/
	
	return 0;
}
