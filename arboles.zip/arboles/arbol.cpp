#include "arbol.h"
#include <fstream>
using std::ifstream;
arbol::arbol() {
	setraizPtr(0);
}

arbol::~arbol() {
	;
}

void arbol::setraizPtr(nodo_a * r) {
	raizPtr = r;
}
nodo_a* arbol::getRaizPtr() {
	return raizPtr;
}

void arbol::insertar(persona i) {
	ayudaInsertar(i, raizPtr);
}
void arbol::leer(string a) {
	ifstream entrada(a.c_str());
	string nom;
	char seso;
	int edad;
	while( !entrada.eof() ) {
		entrada>>nom>>seso>>edad;
		persona y(nom,seso,edad);
		//insertarFinal(y);
		insertar(y);
	}
	cout<<"Los Datos han sido Leidos."<<endl;
}

void arbol::ayudaInsertar(persona a, nodo_a * &raizLocal) {
	if(raizLocal == 0) {
		nodo_a *temp = new nodo_a(a);
		raizLocal = temp;
		cout<<"Dato insertado "<<a.getNombre()<<endl;
	} else {
		if(a.getNombre() < raizLocal->getValor().getNombre()) {
			cout<<"Va por la izquierda "<<a.getNombre()<<endl;
			ayudaInsertar(a, raizLocal->uno());	//uno:devuelve la poscision de memoria
		} else {
			if(a.getNombre() > raizLocal->getValor().getNombre()) {
				cout<<"Va por la derercha "<<a.getNombre()<<endl;
				ayudaInsertar(a, raizLocal->dos());
			} else {
				cout<<"Dato duplicado "<<a.getNombre()<<endl;
			}
		}
	}
}
void arbol::inOrden() {
	mostrarInOrden(getRaizPtr());
}
void arbol::mostrarInOrden(nodo_a * raizLocal) {
	if( raizLocal != 0) {
		mostrarInOrden(raizLocal->getizPtr());	//recursividad por la izquierda
		cout<<raizLocal->getValor().getNombre()<<endl;
		mostrarInOrden(raizLocal->getdePtr());	//recursividad por la derecha
	}
}

void arbol::preOrden() {
	mostrarPreOrden(getRaizPtr());
}

void arbol::mostrarPreOrden(nodo_a * raizLocal) {
	if( raizLocal != 0) {
		cout<<raizLocal->getValor().getNombre()<<endl;
		mostrarInOrden(raizLocal->getizPtr());	//recursividad por la izquierda
		mostrarInOrden(raizLocal->getdePtr());	//recursividad por la derecha
}
}

void arbol::posOrden() {
	mostrarPosOrden(getRaizPtr());
}

void arbol::mostrarPosOrden(nodo_a * raizLocal) {
	if( raizLocal != 0) {
		mostrarInOrden(raizLocal->getizPtr());	//recursividad por la izquierda
		mostrarInOrden(raizLocal->getdePtr());	//recursividad por la derecha
		cout<<raizLocal->getValor().getNombre()<<endl;

	}
}
void arbol::imprimir() {
	cout<<"La raiz apunta a: "<<getRaizPtr()<<endl;
}
