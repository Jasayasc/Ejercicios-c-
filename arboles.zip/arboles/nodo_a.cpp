#include "nodo_a.h"

nodo_a::nodo_a(){
	setizPtr(0);
	setdePtr(0);
	//setValor(0);
}

nodo_a::nodo_a(persona a){
	setValor(a);
	setizPtr(0);
	setdePtr(0);
}

nodo_a::~nodo_a(){
	;
}

void nodo_a::setizPtr(nodo_a *i){
	izPtr = i;
}
void nodo_a::setdePtr(nodo_a *d){
	dePtr = d;
}
void nodo_a::setValor(persona v){
	valor = v;
}

nodo_a* nodo_a::getizPtr(){
	return izPtr;
}
nodo_a* nodo_a::getdePtr(){
	return dePtr;
}
persona nodo_a::getValor(){
	return valor;
}

void nodo_a::imprimir(){
	cout<<"Nodo izquierdo = "<<getizPtr()<<endl;
	cout<<"Nodo derecho = "<<getdePtr()<<endl;
	cout<<"Dato Persona = "<<endl;
	getValor().imprimir();
}

nodo_a * & nodo_a::uno()
{
	return izPtr;	//devuelve la posicion de emoria de izqPtr
}
nodo_a * & nodo_a::dos()
{
	return dePtr;	//devuelve la posicion de emoria de dePtr
}

