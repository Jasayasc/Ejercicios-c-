#ifndef NODO_A_H
#define NODO_A_H




#include "persona.h"
class nodo_a
{
	//friend class arbol;
	private:
	persona valor;
	nodo_a *izPtr;
	nodo_a *dePtr;
	public:
		nodo_a();
		nodo_a(persona);
		~nodo_a();
		
		void setizPtr(nodo_a *);
		void setdePtr(nodo_a *);
		void setValor(persona);
		
		nodo_a* getizPtr();
		nodo_a* getdePtr();
		persona getValor();
		
		void imprimir();
		nodo_a * & uno();
		nodo_a * & dos();
		
	protected:
};

#endif
